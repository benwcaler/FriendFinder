var friends = [{ "name": "Paws", "photo": "http://r.ddmcdn.com/w_830/s_f/o_1/cx_0/cy_66/cw_288/ch_162/APL/uploads/2014/10/cat_5-1.jpg", score: [3, 5, 4, 2, 3, 3, 5, 4, 1, 2] }, { "name": "Pookie", "photo": "http://www.petmd.com/sites/default/files/what-does-it-mean-when-cat-wags-tail.jpg", "score": [3, 5, 4, 1, 2, 4, 4, 3, 1, 5] }, { "name": "George", "photo": "https://d2kwjcq8j5htsz.cloudfront.net/2017/06/05150738/hosico.jpg", "score": [2, 1, 3, 5, 4, 2, 4, 5, 1, 2] }, {
  "name": "Billy-bob", "photo": "http://www.catster.com/wp-content/uploads/2017/08/A-fluffy-cat-looking-funny-surprised-or-concerned.jpg", "scores": [4, 5, 3, 4, 2, 1, 2, 2, 4, 5]
}];

module.exports = friends;